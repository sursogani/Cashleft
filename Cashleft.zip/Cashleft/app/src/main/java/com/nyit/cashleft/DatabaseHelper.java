package com.nyit.cashleft;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="register.db";
    public static final String TABLE_NAME="register";

    //Columns
    public static final String COL_1="ID";
    public static final String COL_2="FirstName";
    public static final String COL_3="LastName";
    public static final String COL_4="Email";
    public static final String COL_5="Password";
    public static final String COL_6="New Email";
    public static final String COL_7="New Password";
    public static final String COL_8="Checking Account";
    public static final String COL_9="Savings Account";
    public static final String COL_10="Routing Bank";
    public static final String COL_11="Credit Card";
    public static final String COL_12="Credit card date";
    public static final String COL_13="Credit card cvv";
    public static final String COL_14="Cash Input";


    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, 1);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " +TABLE_NAME+ "(ID INTEGER PRIMARY KEY AUTOINCREMENT, firstName TEXT, lastName TEXT, password TEXT, email TEXT," +
                " newEmail TEXT, newPass TEXT, checking NUM, savings NUM, routing NUM, creditCard NUM, creditDate NUM, creditCvv NUM, cash NUM)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);//Drop older table is exists
        onCreate(db);

    }
}
